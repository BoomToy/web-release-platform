#!/usr/bin/env python3
"""
Random Video Sampler
从多个文件夹中随机抽取视频文件，整理到按时间命名的输出目录
"""

import os
import shutil
import random
import datetime
from pathlib import Path


def get_base_path() -> Path:
    """获取基础路径"""
    print("请选择视频源文件夹：")
    print("1. 当前脚本所在目录")
    print("2. 指定其他路径")

    choice = input("请输入选项 (1/2): ").strip()

    if choice == "2":
        while True:
            path_str = input("请输入文件夹路径: ").strip()
            path = Path(path_str)
            if path.exists() and path.is_dir():
                return path
            print("路径无效，请重新输入")
    else:
        return Path(__file__).parent.resolve()

    return Path(__file__).parent.resolve()


def get_subfolders(base_path: Path) -> list[Path]:
    """获取所有子文件夹，排除 output"""
    subfolders = []
    for item in base_path.iterdir():
        if item.is_dir() and item.name != "output":
            subfolders.append(item)
    return sorted(subfolders)


def get_video_count() -> int:
    """获取每个文件夹要抽取的视频数量"""
    while True:
        count_str = input("每个文件夹要抽取的视频数量: ").strip()
        try:
            count = int(count_str)
            if count > 0:
                return count
            print("请输入正整数")
        except ValueError:
            print("无效输入，请输入正整数")


def get_extensions() -> list[str]:
    """获取视频文件扩展名"""
    default_exts = ["mp4", "mov", "avi", "mkv", "wmv", "flv"]
    print(f"默认扩展名: {', '.join(default_exts)}")
    use_custom = input("是否使用自定义扩展名? (y/N): ").strip().lower()

    if use_custom == "y":
        exts_str = input("请输入扩展名 (用逗号分隔): ").strip()
        return [ext.strip().lstrip(".").lower() for ext in exts_str.split(",")]
    return default_exts


def find_videos(folder: Path, extensions: list[str]) -> list[Path]:
    """查找文件夹中所有指定扩展名的视频文件"""
    videos = []
    for ext in extensions:
        videos.extend(folder.glob(f"*.{ext}"))
        videos.extend(folder.glob(f"*.{ext.upper()}"))
    return sorted(set(videos))


def sample_videos(folder: Path, video_count: int, extensions: list[str]) -> list[Path]:
    """从文件夹中随机抽取指定数量的视频"""
    all_videos = find_videos(folder, extensions)
    if len(all_videos) <= video_count:
        return all_videos
    return random.sample(all_videos, video_count)


def preview_and_confirm(files: list[Path], base_path: Path) -> tuple[bool, Path]:
    """预览文件列表并请求确认，返回 (是否确认, 输出目录)"""
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H-%M-%S")
    output_dir = base_path / "output" / timestamp

    print(f"\n=== 预览待移动文件 ({len(files)} 个) ===")
    for f in files:
        print(f"  {f.parent.name}/{f.name}")

    print(f"\n目标目录: {output_dir}")
    print()

    confirm = input("确认执行移动? (输入 'yes' 确认): ").strip()
    return confirm.lower() == "yes", output_dir


def move_files(files: list[Path], output_dir: Path) -> tuple[int, int]:
    """移动文件到目标目录，返回 (成功数, 失败数)"""
    output_dir.mkdir(parents=True, exist_ok=True)

    success = 0
    failed = 0
    used_names = set()

    for src in files:
        target_name = src.name
        target_path = output_dir / target_name

        # 处理同名文件
        if target_name in used_names or target_path.exists():
            base, ext = src.stem, src.suffix
            counter = 1
            while target_path.exists() or target_path.name in used_names:
                target_name = f"{base}_{counter}{ext}"
                target_path = output_dir / target_name
                counter += 1

        try:
            shutil.move(str(src), str(target_path))
            success += 1
            print(f"  移动: {src.name}")
        except Exception as e:
            failed += 1
            print(f"  失败: {src.name} - {e}")

        used_names.add(target_path.name)

    return success, failed


def main():
    """主函数"""
    print("=== Random Video Sampler ===")
    print()

    # 1. 获取基础路径
    base_path = get_base_path()
    print(f"使用路径: {base_path}")
    print()

    # 2. 获取子文件夹
    subfolders = get_subfolders(base_path)
    if not subfolders:
        print("未找到子文件夹（排除 output）")
        return

    print(f"找到 {len(subfolders)} 个子文件夹")
    print()

    # 3. 获取配置
    video_count = get_video_count()
    extensions = get_extensions()
    print(f"扩展名: {', '.join(extensions)}")
    print()

    # 4. 收集待移动文件
    all_files = []
    skipped_folders = []

    for folder in subfolders:
        all_videos = find_videos(folder, extensions)
        if not all_videos:
            print(f"跳过 {folder.name}: 未找到视频文件")
            continue

        sampled = sample_videos(folder, video_count, extensions)
        print(f"{folder.name}: 找到 {len(all_videos)} 个视频，抽样 {len(sampled)} 个")

        if len(all_videos) < video_count:
            skipped_folders.append(folder.name)

        all_files.extend(sampled)

    print()

    # 5. 预览确认
    if not all_files:
        print("没有文件需要移动")
        return

    confirmed, output_dir = preview_and_confirm(all_files, base_path)
    if not confirmed:
        print("操作已取消")
        return

    # 6. 执行移动
    print("\n开始移动文件...")
    success, failed = move_files(all_files, output_dir)
    print(f"\n完成: 成功 {success} 个，失败 {failed} 个")
    print(f"输出目录: {output_dir}")

    if skipped_folders:
        print(f"\n警告: 以下文件夹视频数量不足: {', '.join(skipped_folders)}")


if __name__ == "__main__":
    main()
