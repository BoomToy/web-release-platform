#!/usr/bin/env python3
"""
文件移动工具 - 根据 Excel 配置移动文件到对应文件夹
"""
import argparse
import shutil
import sys
from pathlib import Path
from typing import Optional


def main():
    parser = argparse.ArgumentParser(
        description='根据 Excel 配置移动文件',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
示例:
  python file_mover.py config.xlsx /path/to/files
  python file_mover.py config.xlsx /path/to/files --preview
  python file_mover.py config.xlsx /path/to/files --undo
  python file_mover.py --generate-template template.xlsx
        '''
    )
    parser.add_argument('excel_path', nargs='?', help='Excel 文件路径')
    parser.add_argument('source_dir', nargs='?', help='源文件目录')
    parser.add_argument('--generate-template', nargs='?', const='template.xlsx', metavar='PATH', help='生成 Excel 模板（默认: 当前目录的 template.xlsx）')
    parser.add_argument('--file-col', default='文件名', help='文件列的列名 (默认: 文件名)')
    parser.add_argument('--folder-col', default='目标文件夹', help='目标文件夹列的列名 (默认: 目标文件夹)')
    parser.add_argument('--sheet', help='工作表名称 (默认: 第一个)')
    parser.add_argument('--preview', action='store_true', help='预览模式，不实际移动文件')
    parser.add_argument('--undo', action='store_true', help='撤回模式，将文件从目标文件夹移回源目录根目录')

    args = parser.parse_args()

    # 生成模板模式
    if args.generate_template:
        generate_template(args.generate_template)
        print(f"模板已生成: {args.generate_template}")
        return

    # 移动文件模式
    if not args.excel_path or not args.source_dir:
        interactive_mode()
        return

    try:
        reader = ExcelReader(
            args.excel_path,
            file_col=args.file_col,
            folder_col=args.folder_col,
            sheet_name=args.sheet
        )
        mappings = reader.read_mappings()
    except FileNotFoundError as e:
        print(f"错误: {e}", file=sys.stderr)
        sys.exit(1)
    except ValueError as e:
        print(f"错误: {e}", file=sys.stderr)
        sys.exit(1)

    mover = FileMover(args.source_dir)

    # 撤回模式
    if args.undo:
        undo_mode(mover, mappings, args.preview)
        return

    # 第一阶段：预览所有操作
    print("[预览模式]...")
    print()

    to_move = []  # 待移动的文件列表
    success_count = 0
    fail_count = 0
    skip_count = 0
    fail_reasons = []
    max_preview = 20
    preview_count = 0

    for file_name, target_folder in mappings:
        file_path = mover.find_file(file_name)

        if file_path is None:
            reason = "文件不存在"
            if preview_count < max_preview:
                print(f"  ✗ {file_name} → {target_folder or '/'} ({reason})")
            fail_reasons.append(f"{file_name}: {reason}")
            fail_count += 1
            preview_count += 1
            continue

        if not target_folder:
            if preview_count < max_preview:
                print(f"  - {file_name} (无目标文件夹，跳过)")
            skip_count += 1
            preview_count += 1
            continue

        target_path = (mover.source_dir / target_folder).resolve()
        if file_path.parent.resolve() == target_path:
            if preview_count < max_preview:
                print(f"  - {file_name} → {target_folder or '/'} (已在正确位置)")
            skip_count += 1
            preview_count += 1
            continue

        if preview_count < max_preview:
            print(f"  → {file_name} → {target_folder or '/'}")
        elif preview_count == max_preview:
            remaining = len(mappings) - max_preview
            print(f"  ... 还有 {remaining} 项")
        to_move.append((file_name, target_folder, file_path))
        success_count += 1
        preview_count += 1

    print()
    print(f"预览结果：将要移动 {success_count} 个文件，失败 {fail_count} 个，跳过 {skip_count} 个")

    if fail_reasons:
        print("\n失败原因：")
        for r in fail_reasons:
            print(f"  - {r}")

    # 预览模式直接结束
    if args.preview:
        return

    # 第二阶段：确认后执行移动
    print()
    if not ask_yes_no("确认执行以上操作？", default='Y'):
        print("操作已取消")
        return

    print("\n[正在移动文件]...")
    actual_success = 0
    actual_fail = 0

    for file_name, target_folder, file_path in to_move:
        if mover.move_file(file_path, target_folder, preview=False):
            print(f"  ✓ {file_name} → {target_folder or '/'}")
            actual_success += 1
        else:
            print(f"  ✗ {file_name} → {target_folder or '/'} (目标文件已存在)")
            actual_fail += 1

    print(f"\n移动完成：成功 {actual_success}，失败 {actual_fail}")


def generate_template(output_path: str):
    """生成 Excel 模板"""
    import openpyxl
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = '文件映射'
    ws.append(['文件名', '目标文件夹'])
    ws.append(['example.txt', '目标文件夹/子文件夹'])
    ws.append(['', ''])
    wb.save(output_path)


def ask_question(prompt: str, default: str = None, validate=None) -> str:
    """询问问题并返回用户输入"""
    if default:
        prompt = f"{prompt} (默认: {default}): "
    else:
        prompt = f"{prompt}: "

    while True:
        try:
            user_input = input(prompt).strip()
            if not user_input and default:
                return default
            if not user_input:
                print("输入不能为空，请重新输入")
                continue
            if validate:
                result, error = validate(user_input)
                if not result:
                    print(f"输入错误: {error}")
                    continue
            return user_input
        except (KeyboardInterrupt, EOFError):
            print("\n操作已取消")
            sys.exit(0)


def ask_path(prompt: str, must_exist: bool = True, default: str = None) -> str:
    """询问路径
    Args:
        prompt: 提示文本
        must_exist: 是否要求路径必须存在
        default: 默认路径
    """
    if default:
        prompt = f"{prompt} (默认: {default})"

    while True:
        path = input(f"{prompt}: ").strip().strip("'\"").strip()
        if not path and default:
            path = default

        if not path:
            print("路径不能为空，请重新输入")
            continue

        p = Path(path)
        if must_exist:
            if not p.exists():
                print(f"路径不存在: {path}")
                continue
            if p.is_file() or p.is_dir():
                return path
        else:
            return path


def ask_yes_no(prompt: str, default: str = None) -> bool:
    """询问是/否问题"""
    if default:
        prompt = f"{prompt} ({default})"
    prompt = f"{prompt} (Y/N): "

    while True:
        try:
            user_input = input(prompt).strip().upper()
            if not user_input and default:
                return default.upper() == 'Y'
            if user_input not in ('Y', 'N'):
                print("请输入 Y 或 N")
                continue
            return user_input == 'Y'
        except (KeyboardInterrupt, EOFError):
            print("\n操作已取消")
            sys.exit(0)


def interactive_mode():
    """交互式引导模式"""
    print("\n" + "=" * 50)
    print("欢迎使用文件移动工具！")
    print("=" * 50)
    print("本工具可以根据 Excel 配置将文件移动到对应文件夹")
    print()
    print("快捷命令（可直接使用）:")
    print("  python file_mover.py --generate-template           # 生成模板到当前目录")
    print("  python file_mover.py config.xlsx /path/to/files   # 直接执行")
    print("  python file_mover.py config.xlsx /path/files --undo  # 撤回移动")
    print()
    print("按回车键开始引导模式...")
    input()

    # 选择操作模式
    print()
    print("请选择操作模式：")
    print("  1. 移动文件")
    print("  2. 撤回文件")
    mode = ask_question("请输入选项 (1/2)", default='1')
    is_undo = (mode == '2')

    # 第1步：询问 Excel 文件
    excel_path = ask_path("第1步：请输入 Excel 文件路径", must_exist=True)

    # 第2步：询问源文件目录
    source_dir = ask_path("第2步：请输入源文件目录路径（文件所在目录）", must_exist=True)

    # 第3步：设置列名
    print()
    print("第3步：列名设置（直接回车使用默认值）")
    file_col = ask_question("  文件名列", default='文件名')
    folder_col = ask_question("  目标文件夹列", default='目标文件夹')

    # 读取 Excel
    try:
        reader = ExcelReader(
            excel_path,
            file_col=file_col,
            folder_col=folder_col
        )
        mappings = reader.read_mappings()
    except FileNotFoundError as e:
        print(f"错误: {e}", file=sys.stderr)
        sys.exit(1)
    except ValueError as e:
        print(f"错误: {e}", file=sys.stderr)
        sys.exit(1)

    mover = FileMover(source_dir)

    # 撤回模式
    if is_undo:
        undo_mode(mover, mappings, preview=False)
        return

    # 第一阶段：预览所有操作
    print("\n[预览模式]...")
    print()

    to_move = []
    success_count = 0
    fail_count = 0
    skip_count = 0
    fail_reasons = []
    max_preview = 20
    preview_count = 0

    for file_name, target_folder in mappings:
        file_path = mover.find_file(file_name)

        if file_path is None:
            reason = "文件不存在"
            if preview_count < max_preview:
                print(f"  ✗ {file_name} → {target_folder or '/'} ({reason})")
            fail_reasons.append(f"{file_name}: {reason}")
            fail_count += 1
            preview_count += 1
            continue

        if not target_folder:
            if preview_count < max_preview:
                print(f"  - {file_name} (无目标文件夹，跳过)")
            skip_count += 1
            preview_count += 1
            continue

        target_path = (mover.source_dir / target_folder).resolve()
        if file_path.parent.resolve() == target_path:
            if preview_count < max_preview:
                print(f"  - {file_name} → {target_folder or '/'} (已在正确位置)")
            skip_count += 1
            preview_count += 1
            continue

        if preview_count < max_preview:
            print(f"  → {file_name} → {target_folder or '/'}")
        elif preview_count == max_preview:
            remaining = len(mappings) - max_preview
            print(f"  ... 还有 {remaining} 项")
        to_move.append((file_name, target_folder, file_path))
        success_count += 1
        preview_count += 1

    print()
    print(f"预览结果：将要移动 {success_count} 个文件，失败 {fail_count} 个，跳过 {skip_count} 个")

    if fail_reasons:
        print("\n失败原因：")
        for r in fail_reasons:
            print(f"  - {r}")

    # 第二阶段：确认后执行移动
    print()
    if not ask_yes_no("确认执行以上操作？", default='Y'):
        print("操作已取消")
        return

    print("\n[正在移动文件]...")
    actual_success = 0
    actual_fail = 0

    for file_name, target_folder, file_path in to_move:
        if mover.move_file(file_path, target_folder, preview=False):
            print(f"  ✓ {file_name} → {target_folder or '/'}")
            actual_success += 1
        else:
            print(f"  ✗ {file_name} → {target_folder or '/'} (目标文件已存在)")
            actual_fail += 1

    print(f"\n移动完成：成功 {actual_success}，失败 {actual_fail}")


def undo_mode(mover: 'FileMover', mappings: list[tuple[str, str]], preview: bool = False):
    """撤回模式：将文件从目标文件夹移回源目录根目录"""
    mode = "[撤回预览]" if preview else "[撤回模式]"
    print(f"{mode}...")
    print("  注意：文件将被移回源目录根目录")
    print()

    success_count = 0
    fail_count = 0
    skip_count = 0

    for file_name, target_folder in mappings:
        if not target_folder:
            skip_count += 1
            continue

        # 文件应该在 target_folder 中
        current_path = mover.source_dir / target_folder / file_name

        if not current_path.exists():
            print(f"  - {file_name} (在 {target_folder} 中未找到，跳过)")
            skip_count += 1
            continue

        if preview:
            print(f"  → {file_name}: {target_folder}/ → / (将移回源目录根目录)")
            success_count += 1
            continue

        # 移回源目录根目录
        try:
            dest_path = mover.source_dir / file_name
            if dest_path.exists():
                print(f"  ✗ {file_name} (源目录根目录已存在同名文件，跳过)")
                fail_count += 1
                continue
            shutil.move(str(current_path), str(dest_path))
            print(f"  ✓ {file_name}: {target_folder}/ → /")
            success_count += 1
        except (PermissionError, OSError) as e:
            print(f"  ✗ {file_name} (移动失败: {e})")
            fail_count += 1

    print(f"\n撤回完成：成功 {success_count}，失败 {fail_count}，跳过 {skip_count}")


class ExcelReader:
    """读取 Excel 文件并返回 文件名→目标文件夹 的映射列表"""

    def __init__(self, excel_path: str, file_col: str = '文件名', folder_col: str = '目标文件夹', sheet_name: str = None):
        self.excel_path = Path(excel_path)
        self.file_col = file_col
        self.folder_col = folder_col
        self.sheet_name = sheet_name

    def read_mappings(self) -> list[tuple[str, str]]:
        """读取 Excel 并返回 [(文件名, 目标文件夹), ...]"""
        if not self.excel_path.exists():
            raise FileNotFoundError(f"Excel 文件不存在: {self.excel_path}")

        import openpyxl
        wb = openpyxl.load_workbook(self.excel_path)

        # 处理工作表不存在的情况
        if self.sheet_name:
            if self.sheet_name not in wb.sheetnames:
                raise ValueError(f"工作表 '{self.sheet_name}' 不存在，可用工作表: {', '.join(wb.sheetnames)}")
            ws = wb[self.sheet_name]
        else:
            ws = wb.active

        # 找到表头行（精确匹配）
        header_row = None
        header_row_num = None
        for i, row in enumerate(ws.iter_rows(values_only=True), 1):
            if row and self.file_col in row and self.folder_col in row:
                header_row = list(row)
                header_row_num = i
                break

        if header_row is None:
            raise ValueError(f"未找到列名 '{self.file_col}' 或 '{self.folder_col}'")

        file_idx = header_row.index(self.file_col)
        folder_idx = header_row.index(self.folder_col)

        mappings = []
        # 从表头下一行开始读取
        for row in ws.iter_rows(min_row=header_row_num + 1, values_only=True):
            # 跳过列数不足的行
            if not row or len(row) <= max(file_idx, folder_idx):
                continue
            if row[file_idx]:
                file_name = str(row[file_idx]).strip()
                folder_name = str(row[folder_idx]).strip() if row[folder_idx] else ''
                if file_name:
                    mappings.append((file_name, folder_name))

        return mappings



class FileMover:
    """文件移动器"""

    def __init__(self, source_dir: str):
        self.source_dir = Path(source_dir)

    def find_file(self, file_name: str) -> Optional[Path]:
        """在源目录中查找文件"""
        # 精确匹配
        path = self.source_dir / file_name
        if path.is_file():
            return path
        # 不区分大小写匹配（Windows 兼容）
        for item in self.source_dir.iterdir():
            if item.is_file() and item.name.lower() == file_name.lower():
                return item
        return None

    def move_file(self, file_path: Path, target_folder: str, preview: bool = False) -> bool:
        """移动文件到目标文件夹"""
        if not target_folder:
            return True  # 无目标，跳过

        target_path = (self.source_dir / target_folder).resolve()

        # 检查文件是否已在正确位置
        if file_path.parent.resolve() == target_path:
            return True  # 已在目标位置

        if preview:
            return True  # 预览模式不实际移动

        # 创建目标目录
        target_path.mkdir(parents=True, exist_ok=True)

        # 检查目标文件是否已存在
        dest_file = target_path / file_path.name
        if dest_file.exists():
            return False

        # 执行移动
        try:
            shutil.move(str(file_path), str(dest_file))
            return True
        except (PermissionError, OSError) as e:
            print(f"  错误: 无法移动文件 {file_path}: {e}")
            return False


if __name__ == '__main__':
    main()
